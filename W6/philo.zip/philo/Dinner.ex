defmodule Dinner do
  #create chopsticks.
  #create philosophers then calll them with their attributes.
end
