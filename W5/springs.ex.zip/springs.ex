defmodule Spring do

  def split(row) do
    list = String.split(row, " ")
    [first, second] = list
    status = String.to_charlist(first);
    seq = String.split(second, ",");
    {status, seq}
  end

  def test()  do

    {:ok, content} = File.read("input.txt");
    to_string(content);
    #IO.puts(content);

    rows = String.split(content, "\n");
    #split a row into two parts (separated by " ").
    data = Enum.map(rows, fn row -> split(row) end )
    [{status, seq}| _] = data

  end



  #def count(status, seq) do

  #end







end
